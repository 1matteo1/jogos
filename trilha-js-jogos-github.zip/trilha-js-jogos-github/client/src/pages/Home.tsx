import { useEffect, useMemo, useState } from "react";
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Check,
  ChevronRight,
  Code2,
  Gamepad2,
  RotateCcw,
  Sparkles,
  Trophy,
  X,
} from "lucide-react";

type GameKey = "guess" | "tic" | "snake";
type Mark = "X" | "O" | null;
type Position = { x: number; y: number };

const gameMeta: Record<GameKey, { number: string; title: string; subtitle: string; tone: string }> = {
  guess: { number: "01", title: "Adivinhe", subtitle: "Condições e números", tone: "orange" },
  tic: { number: "02", title: "Jogo da velha", subtitle: "Listas e eventos", tone: "yellow" },
  snake: { number: "03", title: "Cobrinha", subtitle: "Loops e renderização", tone: "mint" },
};

const winLines = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6],
];

function getWinner(board: Mark[]) {
  for (const [a, b, c] of winLines) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a];
  }
  return board.every(Boolean) ? "draw" : null;
}

function GamePicker({ active, onPick }: { active: GameKey; onPick: (game: GameKey) => void }) {
  return (
    <aside className="game-picker" aria-label="Selecionar jogo">
      <div className="picker-eyebrow">SELECIONE A FASE</div>
      {(Object.keys(gameMeta) as GameKey[]).map((key) => {
        const game = gameMeta[key];
        return (
          <button
            className={`picker-option ${active === key ? "active" : ""} ${game.tone}`}
            key={key}
            onClick={() => onPick(key)}
            type="button"
          >
            <span className="option-number">{game.number}</span>
            <span className="option-copy"><strong>{game.title}</strong><small>{game.subtitle}</small></span>
            <ChevronRight size={18} aria-hidden="true" />
          </button>
        );
      })}
      <div className="picker-tip"><Sparkles size={16} /> Tudo acontece no navegador. Sem instalação.</div>
    </aside>
  );
}

function GuessGame() {
  const [target, setTarget] = useState(() => Math.floor(Math.random() * 20) + 1);
  const [value, setValue] = useState("");
  const [attempts, setAttempts] = useState(0);
  const [message, setMessage] = useState("Escolha um número e faça sua primeira tentativa.");
  const [won, setWon] = useState(false);

  const reset = () => {
    setTarget(Math.floor(Math.random() * 20) + 1);
    setValue("");
    setAttempts(0);
    setWon(false);
    setMessage("Novo desafio: o número secreto está entre 1 e 20.");
  };

  const tryGuess = () => {
    const guess = Number(value);
    if (!Number.isInteger(guess) || guess < 1 || guess > 20) {
      setMessage("Use um número inteiro de 1 a 20.");
      return;
    }
    setAttempts((current) => current + 1);
    if (guess === target) {
      setWon(true);
      setMessage(`Acertou! ${guess} era o número secreto.`);
    } else if (guess < target) {
      setMessage("Quase! Tente um número maior.");
    } else {
      setMessage("Está alto demais. Tente um número menor.");
    }
    setValue("");
  };

  return (
    <section className="play-card guess-card" aria-labelledby="guess-title">
      <div className="card-topline"><span className="phase-label">FASE 01 · CONDICIONAIS</span><span className="live-dot">AO VIVO</span></div>
      <div className="game-heading">
        <div className="game-icon orange-icon"><span>?</span></div>
        <div><h3 id="guess-title">Adivinhe o número</h3><p>O computador escolheu um valor de <b>1 a 20</b>. Qual é o palpite?</p></div>
      </div>
      <div className={`guess-stage ${won ? "won" : ""}`}>
        <span className="secret-label">NÚMERO SECRETO</span>
        <strong>{won ? target : "??"}</strong>
      </div>
      <div className="guess-controls">
        <label htmlFor="guess-input" className="sr-only">Seu palpite</label>
        <input
          id="guess-input"
          inputMode="numeric"
          max="20"
          min="1"
          onChange={(event) => setValue(event.target.value.replace(/[^0-9]/g, ""))}
          onKeyDown={(event) => event.key === "Enter" && tryGuess()}
          placeholder="Seu palpite"
          value={value}
          disabled={won}
        />
        <button className="primary-action" onClick={tryGuess} type="button" disabled={won}>Testar <ChevronRight size={18} /></button>
      </div>
      <div className={`feedback ${won ? "success" : ""}`}><span>{won ? <Check size={17} /> : <Code2 size={17} />}</span>{message}</div>
      <div className="game-footer"><span><b>{attempts}</b> tentativas</span><button onClick={reset} type="button"><RotateCcw size={15} /> Recomeçar</button></div>
    </section>
  );
}

function TicTacToe() {
  const [board, setBoard] = useState<Mark[]>(Array(9).fill(null));
  const [thinking, setThinking] = useState(false);
  const result = getWinner(board);
  const reset = () => { setBoard(Array(9).fill(null)); setThinking(false); };

  const makeComputerMove = (latest: Mark[]) => {
    const available = latest.map((mark, index) => mark ? -1 : index).filter((index) => index !== -1);
    if (!available.length || getWinner(latest)) return;
    const winningMove = (mark: "X" | "O") => available.find((index) => {
      const probe = [...latest]; probe[index] = mark; return getWinner(probe) === mark;
    });
    const choice = winningMove("O") ?? winningMove("X") ?? available[Math.floor(Math.random() * available.length)];
    window.setTimeout(() => { setBoard((current) => current.map((mark, index) => index === choice ? "O" : mark)); setThinking(false); }, 380);
  };

  const play = (index: number) => {
    if (board[index] || result || thinking) return;
    const next = [...board];
    next[index] = "X";
    setBoard(next);
    if (!getWinner(next)) { setThinking(true); makeComputerMove(next); }
  };

  const status = result === "X" ? "Você venceu a rodada!" : result === "O" ? "O computador venceu desta vez." : result === "draw" ? "Deu velha — empate." : thinking ? "Computador está pensando…" : "Sua vez: marque um X.";
  return (
    <section className="play-card tic-card" aria-labelledby="tic-title">
      <div className="card-topline"><span className="phase-label">FASE 02 · ARRAYS + DOM</span><span className="versus">VOCÊ <b>×</b> CPU</span></div>
      <div className="game-heading">
        <div className="game-icon yellow-icon"><span>×</span></div>
        <div><h3 id="tic-title">Jogo da velha</h3><p>Clique em uma casa. Cada jogada atualiza o estado do tabuleiro.</p></div>
      </div>
      <div className="tic-layout">
        <div className="tic-board" aria-label="Tabuleiro do jogo da velha">
          {board.map((mark, index) => <button className={`tic-cell ${mark === "X" ? "x" : mark === "O" ? "o" : ""}`} onClick={() => play(index)} type="button" key={index} aria-label={`Casa ${index + 1}`}>{mark}</button>)}
        </div>
        <div className="tic-aside">
          <div className="turn-chip"><span className="turn-x">X</span> Você joga primeiro</div>
          <p>{status}</p>
          <button className="secondary-action" onClick={reset} type="button"><RotateCcw size={15} /> Nova rodada</button>
        </div>
      </div>
      <div className="game-footer"><span><b>Array[9]</b> armazena o estado</span><span className="code-sample">addEventListener('click')</span></div>
    </section>
  );
}

const boardSize = 12;
const samePosition = (a: Position, b: Position) => a.x === b.x && a.y === b.y;
function nextFood(occupied: Position[], score: number) {
  for (let shift = 1; shift < boardSize * boardSize; shift += 1) {
    const value = (score * 31 + shift * 17) % (boardSize * boardSize);
    const candidate = { x: value % boardSize, y: Math.floor(value / boardSize) };
    if (!occupied.some((position) => samePosition(position, candidate))) return candidate;
  }
  return { x: 10, y: 10 };
}

function SnakeGame() {
  const initialSnake = useMemo<Position[]>(() => [{ x: 5, y: 6 }, { x: 4, y: 6 }, { x: 3, y: 6 }], []);
  const [snake, setSnake] = useState<Position[]>(initialSnake);
  const [food, setFood] = useState<Position>({ x: 8, y: 4 });
  const [direction, setDirection] = useState<Position>({ x: 1, y: 0 });
  const [running, setRunning] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);

  const reset = () => { setSnake(initialSnake); setFood({ x: 8, y: 4 }); setDirection({ x: 1, y: 0 }); setRunning(false); setGameOver(false); setScore(0); };
  const setSafeDirection = (next: Position) => {
    setDirection((current) => current.x + next.x === 0 && current.y + next.y === 0 ? current : next);
    setRunning(true);
  };

  useEffect(() => {
    const keyHandler = (event: KeyboardEvent) => {
      const arrows: Record<string, Position> = { ArrowUp: { x: 0, y: -1 }, ArrowDown: { x: 0, y: 1 }, ArrowLeft: { x: -1, y: 0 }, ArrowRight: { x: 1, y: 0 } };
      if (arrows[event.key]) { event.preventDefault(); setSafeDirection(arrows[event.key]); }
    };
    window.addEventListener("keydown", keyHandler);
    return () => window.removeEventListener("keydown", keyHandler);
  }, []);

  useEffect(() => {
    if (!running || gameOver) return;
    const timer = window.setTimeout(() => {
      setSnake((current) => {
        const head = current[0];
        const next = { x: head.x + direction.x, y: head.y + direction.y };
        const hitWall = next.x < 0 || next.y < 0 || next.x >= boardSize || next.y >= boardSize;
        const hitSelf = current.some((part) => samePosition(part, next));
        if (hitWall || hitSelf) { setGameOver(true); setRunning(false); return current; }
        const ate = samePosition(next, food);
        const grown = [next, ...current];
        if (ate) {
          setScore((currentScore) => currentScore + 1);
          setFood(nextFood(grown, score + 1));
          return grown;
        }
        return grown.slice(0, -1);
      });
    }, 185);
    return () => window.clearTimeout(timer);
  }, [running, gameOver, snake, direction, food, score]);

  return (
    <section className="play-card snake-card" aria-labelledby="snake-title">
      <div className="card-topline"><span className="phase-label">FASE 03 · LOOP DE ANIMAÇÃO</span><span className="score-pill">PONTOS <b>{score.toString().padStart(2, "0")}</b></span></div>
      <div className="game-heading">
        <div className="game-icon mint-icon"><span>~</span></div>
        <div><h3 id="snake-title">Cobrinha</h3><p>Use as setas do teclado ou os controles. Faça a cobrinha comer os pontos.</p></div>
      </div>
      <div className="snake-layout">
        <div className="snake-board" aria-label="Tabuleiro da cobrinha">
          {Array.from({ length: boardSize * boardSize }, (_, index) => {
            const point = { x: index % boardSize, y: Math.floor(index / boardSize) };
            const isHead = samePosition(snake[0], point);
            const isSnake = snake.some((part) => samePosition(part, point));
            const isFood = samePosition(food, point);
            return <span key={index} className={`snake-cell ${isSnake ? "snake" : ""} ${isHead ? "head" : ""} ${isFood ? "food" : ""}`} />;
          })}
          {!running && !gameOver && <div className="board-message"><b>Pressione uma seta</b><span>para começar</span></div>}
          {gameOver && <div className="board-message game-over"><b>Fim de jogo</b><button onClick={reset} type="button">Tentar de novo</button></div>}
        </div>
        <div className="snake-aside"><p>Loop ativo com <code>setInterval</code> e renderização a cada movimento.</p><div className="direction-pad"><button onClick={() => setSafeDirection({ x: 0, y: -1 })} type="button" aria-label="Mover para cima"><ArrowUp size={17} /></button><button onClick={() => setSafeDirection({ x: -1, y: 0 })} type="button" aria-label="Mover para esquerda"><ArrowLeft size={17} /></button><button onClick={() => setSafeDirection({ x: 0, y: 1 })} type="button" aria-label="Mover para baixo"><ArrowDown size={17} /></button><button onClick={() => setSafeDirection({ x: 1, y: 0 })} type="button" aria-label="Mover para direita"><ArrowRight size={17} /></button></div><button className="secondary-action" onClick={reset} type="button"><RotateCcw size={15} /> Reiniciar</button></div>
      </div>
      <div className="game-footer"><span><b>keydown</b> move a direção</span><span className="code-sample">requestAnimationFrame()</span></div>
    </section>
  );
}

export default function Home() {
  const [active, setActive] = useState<GameKey>("guess");
  const showGame = () => document.getElementById("laboratorio")?.scrollIntoView({ behavior: "smooth" });
  return (
    <div className="site-shell">
      <header className="topbar">
        <a className="brand" href="#inicio" aria-label="Trilha JS início"><span>JS</span><i /> trilha</a>
        <nav><a href="#como-funciona">Como funciona</a><a href="#laboratorio">Jogos</a><a href="#mapa">Mapa da trilha</a></nav>
        <button className="nav-cta" onClick={showGame} type="button">Começar <ArrowDown size={15} /></button>
      </header>

      <main id="inicio">
        <section className="hero">
          <div className="hero-grid" aria-hidden="true" />
          <div className="hero-copy">
            <div className="eyebrow"><span /> APRENDA FAZENDO</div>
            <h1>Construa lógica.<br /><em>Jogue</em> código.</h1>
            <p>Uma trilha prática para transformar conceitos de JavaScript em pequenas experiências que você pode testar agora.</p>
            <div className="hero-actions"><button className="hero-button" onClick={showGame} type="button">Escolher um jogo <ChevronRight size={19} /></button><span className="time-note">3 desafios<br />sem cadastro</span></div>
          </div>
          <div className="hero-visual" aria-label="Visualização da trilha de jogos">
            <div className="orbit orbit-a" /><div className="orbit orbit-b" />
            <div className="floating-tag tag-one">if / else</div><div className="floating-tag tag-two">[ array ]</div><div className="floating-tag tag-three">loop()</div>
            <div className="hero-console"><div className="console-dots"><i /><i /><i /></div><span>&gt; aprender()</span><strong>divirta-se.</strong><div className="console-cursor" /></div>
            <div className="hero-sticker"><Gamepad2 size={26} /><span>PLAY<br />WITH JS</span></div>
          </div>
          <div className="hero-footer"><span>ROLE PARA EXPLORAR</span><div className="scroll-line" /><span>01 — 03</span></div>
        </section>

        <section className="intro-section" id="como-funciona">
          <div className="intro-lead"><span className="section-kicker">A PROGRESSÃO</span><h2>Do primeiro <em>if</em> ao<br />movimento na tela.</h2></div>
          <div className="intro-copy"><p>Estes três jogos refletem uma evolução direta no aprendizado de lógica de programação com JavaScript.</p><p>Cada fase adiciona uma camada de raciocínio, sem perder o principal: <b>ver imediatamente o resultado do seu código.</b></p></div>
        </section>

        <section className="curriculum" id="mapa">
          <div className="timeline-line" aria-hidden="true" />
          <article className="level-card level-one"><span className="level-badge">NÍVEL 1</span><div className="level-mark">?</div><h3>Adivinhe o número</h3><p>Trabalha a lógica condicional <code>if/else</code> e a manipulação básica de entradas de texto e botões no HTML.</p><span className="concept">CONDIÇÕES + NÚMEROS</span></article>
          <article className="level-card level-two"><span className="level-badge">NÍVEL 2</span><div className="level-mark">×</div><h3>Jogo da velha</h3><p>Trabalha com matrizes e listas para controlar o estado do tabuleiro e os eventos de clique.</p><span className="concept">LISTAS + EVENTOS</span></article>
          <article className="level-card level-three"><span className="level-badge">NÍVEL 3</span><div className="level-mark">~</div><h3>Cobrinha</h3><p>Trabalha com uma API Canvas, eventos do teclado e um loop de animação contínuo.</p><span className="concept">LOOP + RENDERIZAÇÃO</span></article>
        </section>

        <section className="table-section">
          <div className="section-heading"><span className="section-kicker">REFERÊNCIA RÁPIDA</span><h2>O que cada jogo<br />coloca em prática.</h2></div>
          <div className="learning-table" role="table" aria-label="Resumo dos conceitos de JavaScript">
            <div className="table-row table-head" role="row"><span>JOGO</span><span>CONCEITO PRINCIPAL EM JS</span><span>ELEMENTO HTML USADO</span></div>
            <div className="table-row" role="row"><strong>Adivinhação</strong><span>Condicionais e números aleatórios <code>Math.random</code></span><span>Form simples (<code>&lt;input&gt;</code> e <code>&lt;button&gt;</code>)</span></div>
            <div className="table-row" role="row"><strong>Jogo da velha</strong><span>Listas (<code>Arrays</code>) e eventos de clique</span><span>Grade dinâmica (<code>&lt;div&gt;</code> com CSS Grid)</span></div>
            <div className="table-row" role="row"><strong>Cobrinha</strong><span>Renderização gráfica e loop de animação</span><span>Quadro de desenho (<code>&lt;canvas&gt;</code>)</span></div>
          </div>
        </section>

        <section className="laboratory" id="laboratorio">
          <div className="lab-header"><div><span className="section-kicker">LABORATÓRIO PRÁTICO</span><h2>Agora é sua vez<br />de <em>jogar.</em></h2></div><p>Selecione uma fase e experimente os conceitos funcionando em tempo real.</p></div>
          <div className="lab-grid"><GamePicker active={active} onPick={setActive} /><div className="game-stage">{active === "guess" && <GuessGame />}{active === "tic" && <TicTacToe />}{active === "snake" && <SnakeGame />}</div></div>
        </section>

        <section className="closing-section"><div className="closing-star"><Trophy size={33} /></div><div><span className="section-kicker">MISSÃO CUMPRIDA?</span><h2>Você não está só<br />aprendendo JS.</h2><p>Está aprendendo a pensar em etapas, estados e possibilidades — do jeito que jogos são construídos.</p></div><button className="closing-button" onClick={() => { setActive("guess"); showGame(); }} type="button">Jogar de novo <RotateCcw size={18} /></button></section>
      </main>
      <footer><span>TRILHA JS / 2026</span><span>feito para aprender <b>na prática</b></span><a href="#inicio">Voltar ao topo ↑</a></footer>
    </div>
  );
}
