# Trilha JS — Aprenda jogando

Site educativo em português para aprender lógica de programação com JavaScript por meio de três jogos interativos:

- **Adivinhe o número** — condicionais, entradas e números aleatórios;
- **Jogo da velha** — arrays, estado e eventos de clique;
- **Cobrinha** — teclado, loop de animação e renderização.

## Como executar localmente

Requisitos: Node.js 18+ e pnpm (ou npm).

```bash
pnpm install
pnpm dev
```

Abra o endereço mostrado pelo Vite, normalmente `http://localhost:5173`.

## Como gerar a versão de produção

```bash
pnpm check
pnpm build
pnpm start
```

## Publicar no GitHub

1. Crie um repositório vazio no GitHub.
2. Dentro desta pasta, inicialize o Git:

```bash
git init
git add .
git commit -m "feat: cria trilha educativa de JavaScript"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/SEU-REPOSITORIO.git
git push -u origin main
```

O projeto é uma aplicação React + TypeScript + Vite + Tailwind CSS.
